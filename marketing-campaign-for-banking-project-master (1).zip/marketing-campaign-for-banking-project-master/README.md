# marketing-campaign-for-banking-project
It predict the likelihood of a liability customer buying personal loans.
